#include <stdio.h>
#include <stdlib.h>
#include <time.h>


extern void sort(Item *, int, int);

int main(int argc, char *argv[]) 
{
    // Input

    // Sort

    // Output
}
